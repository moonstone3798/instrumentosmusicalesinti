

<?php $__env->startSection('contenido'); ?>

        <h1 style="margin-top: 5%"><?php echo e($Artista->nombre); ?></h1>
<br>
<div  class="modal"  id="img1">

<div class="imagenes">
<?php
if( $Artista->imagen2 ==!NULL){
    echo '<a href="#img2">&#60;</a>';

}
?>

    <img src="/artistas/<?php echo e($Artista->imagen); ?>" style="width:600px; height:550px; object-fit:fill">

    <?php
if( $Artista->imagen2 ==!NULL){
   
    echo ' <a href="#img2">></a>';
}
?>
</div>
</div>


<div  class="modal" id="img2">
<div class="imagenes">
    <a href="#img1">&#60;</a>
   <img src="/artistas/<?php echo e($Artista->imagen2); ?>" style="width:600px; height:550px; object-fit:fill">
    <a href="#img1">></a>
</div>
</div>


<br><br>

        



        <?php if( $errors->any() ): ?>
            <div class="alert alert-danger col-8 mx-auto p-2">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/mostrarArtista.blade.php ENDPATH**/ ?>