<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Instrumentos Inti</title>
    <link rel="stylesheet" href="/css/estilos.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Original+Surfer&display=swap" rel="stylesheet">
<style>
    ul{margin-top: 5%;}
</style>
</head>
<body>
    <header class="header">
        <div class="barra">
            <img src="../productos/logo.jpg" alt="" style="width:14%;float: right;" >
        <nav>
     
            <a href="/adminArtistas" title="adminArtistas">Artistas</a>
            <a href="/adminProductos" title="adminProductos">Productos</a>
            <a href="/adminAcusticos" title="adminAcusticos">Acusticos</a>
            <a href="/adminElectricos" title="adminElectricos">Electricos</a>
            <a href="/adminTipos" title="adminTipos">Tipos</a>
            <a href="/adminMateriales" title="adminMateriales">Materiales</a>
           
            </nav>

        </div>
    </header>
<?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/layouts/headerad.blade.php ENDPATH**/ ?>