<footer>

    <p>¿Querés volver a la página pública de Instrumentos Inti? Clickea Acá</p>

</footer>
</body>
</html><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/layouts/footerad.blade.php ENDPATH**/ ?>