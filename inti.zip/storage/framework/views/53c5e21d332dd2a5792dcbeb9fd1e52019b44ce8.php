<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
<h1 style="text-align:center">Administrar Productos</h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="background:rgba(255, 255, 255, 0.329)">
            

<br>
<?php if( session('mensaje') ): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>

        <table class="table table-borderless table-striped table-hover" style="width:106%; padding-left:0%">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Tipo</th>
                    <th>Categoría</th>
                    <th>Trastes</th>
                    <th>Cuerpo</th>
                    <th style="width: 103%">Mango</th>
                    <th>Electronica</th>
                    <th>Accesorios</th>
                    <th>Misceláneos</th>
                    <th>Imagen</th>
                    <th colspan="2">
                        <button>  <a href="/agregarProducto" class="btn btn-outline-secondary">
                            Agregar
                        </a></button>
                    </th>
                </tr>
            </thead>
            <tbody>
<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->nombre); ?></td>
                    <td>$<?php echo e($producto->precio); ?></td>
                    <td><?php echo e($producto->relTipo->tipo); ?></td>
                    <td><?php echo e($producto->categoria); ?></td>
                    <td><?php echo e($producto->trastes); ?></td>
                    <td><?php echo e($producto->cuerpo); ?></td>
                    <td ><?php echo e($producto->mango); ?></td>
                    <td><?php echo e($producto->electronica); ?></td>
                    <td style="width: 102%"><?php echo e($producto->accesorios); ?></td>
                    <td><?php echo e($producto->miscelaneos); ?></td>
                    <td><img src="/productos/<?php echo e($producto->imagen); ?>" class="img-thumbnail" style="width: 100%"></td>
                    <td>
                        <button >    <a href="/modificarProducto/<?php echo e($producto->id); ?>" class="btn btn-outline-secondary">
                            Modificar
                        </a></button>
                    </td>
                    <td>
                        <button><a href="/eliminarProducto/<?php echo e($producto->id); ?>" class="btn btn-outline-secondary">
                            Eliminar
                        </a></button>
                    </td>
                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<br><br>
        <?php echo e($productos->links()); ?>

        </div>


</div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/adminProductos.blade.php ENDPATH**/ ?>