<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
<h1 style="text-align:center">Modificación de un producto</h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="background:rgba(255, 255, 255, 0.329)">
            

<br>
<?php if( session('mensaje') ): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>

        <div class="alert bg-light border border-white shadow round col-8 mx-auto p-4">

            <form action="/modificarProducto" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
              <label>Nombre</label>  
                <input type="text" name="nombre"
                       value="<?php echo e(old('nombre', $Producto->nombre)); ?>"
                       class="form-control">
                <br> <br>
                <label>Precio $ </label>
                    <input type="number" name="precio"
                           value="<?php echo e(old('precio', $Producto->precio)); ?>"
                           class="form-control" step="0.01">
            
                <br><br>
                <label>Tipo de instrumento </label>
                <select name="tipo" class="form-control" required>
                    <option value="">Seleccione una marca</option>
           <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($Producto->tipo == $tipo->id)?'selected':''); ?> value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->tipo); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br> <br>
                <label>Categoría</label>
                <select name="categoria" class="form-control" required>
                    <option <?php echo e(($Producto->categoria)?'selected':''); ?> value="<?php echo e($Producto->categoria); ?>"><?php echo e($Producto->categoria); ?></option>
           <option value="acustica">acustica</option>
           <option value="acustico">acustico</option>
           <option value="electrico">eléctrico</option>
           <option value="electrica">eléctrica</option>
                </select>
                <br><br>
                <label>Cantidad de trastes</label>
                <input type="number" name="trastes" value="<?php echo e(old('trastes', $Producto->trastes)); ?>"
                           class="form-control"> <br><br>
                    
                <br>
                <label>Específicaciones del cuerpo</label><br>
                <textarea name="cuerpo" id="cuerpo" cols="50" rows="14"><?php echo e($Producto->cuerpo); ?></textarea>
                <br><br>
                <label>Específicaciones del mango</label><br>
                <textarea name="mango" id="mango" cols="50" rows="14"><?php echo e($Producto->mango); ?></textarea>
                <br><br>

                <label>Específicaciones de electronica</label><br>
                <textarea name="electronica" id="electronica" cols="50" rows="12" ><?php echo e($Producto->electronica); ?> </textarea>
                <br><br>
                <label>Específicaciones de los accesorios</label><br>
                <textarea name="accesorios" id="accesorios" cols="50" rows="14" ><?php echo e($Producto->accesorios); ?></textarea>
                <br><br>
                <label>Específicaciones del miscelaneo</label><br>
                <textarea name="miscelaneos" id="miscelaneos" cols="50" rows="8"><?php echo e($Producto->miscelaneos); ?> </textarea> <br>
                <label>Imagen actual </label> <br><br>
                <img src="/productos/<?php echo e($Producto->imagen); ?>" class="img-thumbnail my-2"style="width: 300px;  height:300px; object-fit:cover; margin-left:37%">
                <br><br>
                <label>Imagen nueva (opcional)</label>
             
                <div class="custom-file mt-1 mb-4">
                    <input type="file" name="imagen"  class="custom-file-input" id="customFileLang" lang="es">
                    <label class="custom-file-label" for="customFileLang" data-browse="Buscar en disco"></label>
                </div>

                <input type="hidden" name="id"
                       value="<?php echo e($Producto->id); ?>">
                <input type="hidden" name="ImagenAnterior"
                       value="<?php echo e($Producto->imagen); ?>">
                <br>    <br>
    
                <button class="btn btn-dark mb-3">Modificar Producto</button>
                <a href="/adminProductos" class="btn btn-outline-secondary mb-3">
                    Volver al panel de productos
                </a>
            </form>
<br><br>
        </div>

        <?php if( $errors->any() ): ?>
            <div class="alert alert-danger col-8 mx-auto p-2">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        </div>


</div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/modificarProducto.blade.php ENDPATH**/ ?>