<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="container" >
  <?php echo $__env->yieldContent('contenido'); ?>  
</main>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>