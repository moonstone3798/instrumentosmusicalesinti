

    <?php $__env->startSection('contenido'); ?>
    <h1 style="margin-top: 5%; margin-bottom:1%">Artistas</h1>
        
        <div class="row" style="width: 100%; ">

            <?php $__currentLoopData = $artistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="now-get get-cart" href="./mostrarArtista/<?php echo e($artista->idArtista); ?>&#img1" style="text-decoration: none; color:white">
                <div class="col" style="margin-bottom:2%;display: inline-block; margin-right:2%; margin-left: 2.8%;width: 28%; height:28%; overflow:hidden; margin-top:3%;">
                    <div class="card" style="border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px, 2px, rgba(0,0,0,0.24);">

                        <img src="/artistas/<?php echo e($artista->imagen); ?>"  style="width: 400px; height:350px; overflow:hidden; object-fit:initial ">
                    
                        <h3 style=" text-align: center; font-size:22px"><?php echo e($artista->nombre); ?></h3>
                         </a>
                         
                    </div>
                   
                </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
        <?php echo e($artistas->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views//artista.blade.php ENDPATH**/ ?>