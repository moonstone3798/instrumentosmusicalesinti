





<?php $__env->startSection('contenido'); ?>

        <h1 style="margin-top: 8%"><?php echo e($Producto->nombre); ?></h1>
<br><br>
<img src="/productos/<?php echo e($Producto->imagen); ?> " style="width: 35%; margin-left:32.5%">
<h2 style="text-align:center; margin-top: 5%">Específicaciones</h2> <br>
<div class="general" id="especificaciones">
<h3>Generales</h3> <br>
<p>Nombre de modelo: <?php echo e($Producto->nombre); ?></p> 
<p>Número de modelo: <?php echo e($Producto->id); ?></p> 
<p><?php echo e($Producto->relTipo->tipo); ?> <?php echo e($Producto->categoria); ?></p> 
</div>
<div class="cuerpo" id="especificaciones">
<h3>Cuerpo</h3><br>
<p><?php echo e($Producto->cuerpo); ?></p><br>
</div>
<div class="mango" id="especificaciones">
    <h3>Mango</h3><br>
    <p><?php echo e($Producto->mango); ?></p> <br>
</div>
<div class="electronica" id="especificaciones">
    <h3>Eléctronica</h3> <br>
    <p><?php echo e($Producto->electronica); ?></p> <br>
</div>

<div class="accesorios" id="especificaciones">
    <h3>Accesorios</h3> <br>
    <p><?php echo e($Producto->accesorios); ?></p> <br>
</div>

<div class="miscelaneos" id="especificaciones">
    <h3>Miscélaneos</h3> <br>
    <p><?php echo e($Producto->miscelaneos); ?></p> <br>

<?php
if( $Producto->relTipo->tipo =="bajo"){
    echo '<p style="margin-top:7%">Puede ser fretless</p>';
}
?>
<br>
</div>
        



        <?php if( $errors->any() ): ?>
            <div class="alert alert-danger col-8 mx-auto p-2">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/inicio&id.blade.php ENDPATH**/ ?>