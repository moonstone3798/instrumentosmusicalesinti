<footer>

<div class="social" >
    <ul>
        <li ><a href="https://m.facebook.com/LuthierInstrumentosMusicalesINTI/" target="_blank"  class="icon-facebook2"></a></li>
        <p style="font-size: 10px">InstrumentosMusicalesINTI</p>
        <li><a href="https://www.instagram.com/instrumentosinti/?hl=es-la" target="_blank" class="icon-instagram"></a></li>
        <p style="font-size: 10px">instrumentosinti</p>
        <li><a href="https://www.youtube.com/channel/UCks8IcD4yp8SkRb4iNMgjrg" target="_blank" class="icon-youtube"></a></li>
        <p style="font-size: 10px">InstrumentosMusicalesINTI</p>
    </ul>
    </div>

</footer>
</body>
</html><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/layouts/footer.blade.php ENDPATH**/ ?>