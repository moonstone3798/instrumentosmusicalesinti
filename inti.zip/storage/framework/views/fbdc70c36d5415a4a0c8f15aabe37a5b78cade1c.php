<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
<h1 style="text-align:center">Administrar Artistas</h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="background:rgba(255, 255, 255, 0.329)">
            

<br>
<?php if( session('mensaje') ): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

    </div>
<?php endif; ?>


<table class="table table-borderless table-striped table-hover">
    <thead>
        <tr>
            <th>Artista</th>
            <th>Imagen</th>
            <th>Imagen2</th>
            <th colspan="2">
                <button style=" width:50%"> <a href="/agregarArtista">
                    Agregar
                </a></button>
            </th>
        </tr>
    </thead>
    <tbody>
<?php $__currentLoopData = $artistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($artista->nombre); ?></td>
            <td><img src="/artistas/<?php echo e($artista->imagen); ?>" class="img-thumbnail" style="width: 250px; height: 200px;  margin-left:15%; object-fit: fill"></td>
            <td><img src="/artistas/<?php echo e($artista->imagen2); ?>" class="img-thumbnail"  style="width: 250px; height: 200px; object-fit:fill; margin-left:15%;"></td>
            <td>
                <button><a href="/modificarArtista/<?php echo e($artista->idArtista); ?>" >
                    Modificar
                </a></button>
                <button>  <a href="/eliminarArtista/<?php echo e($artista->idArtista); ?>">
                    Eliminar
                </a></button>
            </td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="d-flex justify-content-center">

    <?php echo e($artistas->links()); ?>

    </div>


</div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views//adminArtistas.blade.php ENDPATH**/ ?>