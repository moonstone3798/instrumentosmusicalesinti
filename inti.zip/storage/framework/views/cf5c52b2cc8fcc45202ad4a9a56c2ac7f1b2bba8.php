<?php echo $__env->make('layouts.headerad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="container">
<div style="margin-top: 5%; margin-bottom:3%">
  <?php echo $__env->yieldContent('contenido'); ?>  
</div>
</main>
<?php echo $__env->make('layouts.footerad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\moons\OneDrive\Escritorio\fin\inti\resources\views/layouts/plantillaad.blade.php ENDPATH**/ ?>