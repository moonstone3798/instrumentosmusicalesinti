@include('layouts.header')
<main class="container" >
  @yield('contenido')  
</main>
@include('layouts.footer')